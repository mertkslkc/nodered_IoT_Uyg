### Node-Red ile IoT Uygulamalarına Giriş Eğitimi Tamamlandı  
  
Böylece sıfırdan IoT bir sistem tasarlamayı hem teorik hem de uygulamalı olarak aşama aşama öğrenmiş olduk.

Tebrikler  Node-Red ile IoT Uygulamalarına Giriş eğitimini tamamladınız. 👏🏻👏🏻👏🏻

![finish](https://media.tenor.com/GoOHTKk2NrcAAAAC/done-im-done.gif)

Profil sayfasına dönmek ve oturumu kapatmak için sonlandır butonuna basınız.
