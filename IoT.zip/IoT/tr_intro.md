# Node-Red ile IoT Uygulamalarına Giriş 
Node-Red ile IoT Uygulamalarına Giriş  Eğitimine hoş geldin... 😊

Bu eğitiminde Node-Red kullanarak IoT bir sistem sıfırdan nasıl tasarlanılır uygulamalı olarak adım adım deneyimlemiş olacağız. Öncelikle Nesnelerin İnterneti (IoT) ve Node-Red nedir bu sorulara bir cevap bulalım…

Kahven de hazırsa eğitime geçelim. 🚀  🚀  🚀 
![Gif](https://tenor.com/view/cats-typing-working-hard-gif-11410471.gif)
