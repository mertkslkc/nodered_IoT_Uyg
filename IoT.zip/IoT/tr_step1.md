## Node-Red Nedir ? 
Node-RED, donanım aygıtlarını, API'leri ve çevrimiçi hizmetleri bağlamayı kolaylaştıran açık kaynaklı bir düğüm grafik geliştirme aracıdır.

![IoT](https://cdn.xingosoftware.com/elektor/images/fetch/dpr_1/https%3A%2F%2Fwww.elektormagazine.com%2Fassets%2Fupload%2Fimages%2F42%2F20200612144414_Node-Red-official-logo.png)

## IoT Nedir ? 

Endüstri 4.0 ile hayatımıza giren Nesnelerin İnterneti (IoT), elektronik cihazların çeşitli sensör ve donanımlarla çevresel durumları algılayabildiği birbirleriyle etkileşim kurarak veri üretebilen aygıtlar topluluğudur. 

![IoT](https://www.pngitem.com/pimgs/m/237-2379257_internet-of-things-illustration-benefits-of-iot-hd.png)

İsminin önüne akıllı adı alan her sistem temelde Nesnelerin İnterneti (IoT) ekosistemine dahildir. Günümüzde artık IoT’nin de katkısıyla elektronik cihazları uzaktan kontrol ve denetleyebilme imkanı bulmaktayız.


IoT bir sistem tasarlamak için bize gerekenler:

* Sunucu (Cloud/Server)
* Veritabanı (Database)
* IoT Yönetim Platformu (Web/Mobile)
* IoT cihaz (Gateway) ‘dır.

![IoT](https://miro.medium.com/v2/resize:fit:720/format:webp/1*N1zG0U6EsXMk0IdJGzc7aw.jpeg)

IoT Sunucu için gerekli bileşenleri ve bunların kurulumlarını ele alacağız. Öncelikle sunucu kurmak için izleyebileceğiniz iki yol var.

![IoT](https://miro.medium.com/v2/resize:fit:640/format:webp/1*QR-O7yTMwogZ11-KoRE0Og.png)

1.  Sunucuyu yerel bir alana kurmak. Bunun için alternatif birçok çözüm mevcut. Örneğin bilgisayarınıza Virtualbox indirerek Ubuntu işletim sistemini kurabilir ya da Raspberry Pi gibi benzer tek kartlı bilgisayarı kullanarak yine bu kurulumu gerçekleştirebilirsiniz.

2.  Bir diğer yöntem ise Bulut Sunucusu (Cloud Server) edinmek. Bu size işletim sistemi kurarken CPU, RAM gibi kaynak tahsisi zorunluluğundan kurtaracaktır. Bulut Bilişimciler platformu sayesinde biz IoT uygulamalarımızı yan taraftaki Bulut sunucu terminali üzerinden gerçekleştireceğiz. Bu sayede vakit alan işlerle uğraşmak yerine sadece IoT uygulama geliştirmeye odaklanacağız. 