## Node-Red Kurulum ?

![Node-Red](https://miro.medium.com/v2/resize:fit:720/format:webp/1*TWqP4JHjcrAl0rmMh8uIpw.png)

Node Red kurulumu için aşağıdaki komutu çalıştırarak kurulum otomasyonunu başlatabilirsiniz. (Kurulum işlemi yaklaşık 1 dakika sürmektedir.)

```
# Node Red Kurulumu - Bu komutu tıklayarak çalıştırabilirsiniz.
docker run -it -p 1880:1880 --name mynodered -v node-red-data:/data -d nodered/node-red:2.2.3-minimal
echo "🔥 Node Red Kurulumu Tamamlandı - http://localhost:1880 🔥" 
```

Kurulum tamamlandıktan sonra terminal ekranın üst tarafında bulunan bağlantı aç simgesine tıklayın.

![Nodered](/img/1.png)

Açılan ekranda **node1** makinesini ve Node-Red sunucusunun çalıştıp çalıştığı port olan **1880** portunu yazın ve yan taraftaki ikondan bağlantıya gidin.

![Nodered](/img/2.PNG)

**Tebrikler, Node-Red uygulamasını başarıyla kurdunuz !**

![Nodered](/img/3.PNG)


