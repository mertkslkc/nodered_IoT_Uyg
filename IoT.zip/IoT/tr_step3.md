## Uygulama-1 Sıcaklık ve Nem Ölçümü

Sıcaklık ve Nem sensörü uygulaması için;
* DHT11 Sıcaklık ve Nem Sensörü
* NodeMCU (ESP8266) gereklidir.

Malzemeler tamamsa, aşağıdaki link üzerinden içerisinde NodeMCU kartına yükleyeceğimiz kod ile devre bağlantı şemaları mevcuttur.

https://github.com/mertkslkc/iot
![Nodered](/img/4.PNG)

Devre Şemasına göre DHT11 sensörünü NodeMCU kartının D4 pinine bağlayın ardından. Github adresinden indirdiğiniz iot-sicaklik.ino dosyasını açın.

![Nodered](https://user-images.githubusercontent.com/77803191/235302087-86698332-61bc-45a3-9875-14529e09fc10.png)

Arduino IDE üzerinde açtığınız dosyada düzenleme yapılacak 3 alan vardır.
*   ssid = Kısmına Kullanmakta olduğunuz wifi adını.
* password = Kısmına Wifi şifresini 
* url = Kısmına ise BulutBilişimciler sitesi üzerinden ayağa kaldırdığımız NodeRed sunucunun adresini giriniz.

Örnek Adres:
```
https://ip10-3-104-4-ch6fb09od340kjsj0hlg-1880-nemrut00oap0.direct.bulutbilisimciler.com

Bu adresinin sonuna /iot uzantısını ekleyin.

https://ip10-3-104-4-ch6fb09od340kjsj0hlg-1880-nemrut00oap0.direct.bulutbilisimciler.com/iot

```
![Nodered](/img/5.PNG)

IoT uzantısını eklediğiniz adresi Arduino IDE üzerinde bulunan url kısmına yapıştırın ve kodu karta yükleyin. IDE üzerinden serial monitor açtığınızda aşağıdaki gibi DHT11 sensörü ile ortamda ölçülen sıcaklık, nem ve hissedilen sıcaklık miktarlarını görebilirsiniz. 
Sunucuya bu verilerin post isteği ile başarılı bir şekilde iletildiğini 200 dönen yanıtı ile anlaşılabilir.
Verilen sunucuya JSON veri tipinde 5 saniye aralıklarla aktarılacaktır. 

![Nodered](/img/6.PNG)

NodeRed ekranında sol yukarda bulunan arama çubuğuna http yazın. Açılan düğümlerden **http in** ve **http response** düğümlerini NodeRed ekranına sürükleyip bırakın. **Http in** düğümü ile gelen post isteklerini nodered üzerinden okunmasına yardımcı olacaktır. **http in** düğümüne çift tıklayın;
* **Method** kısmını **POST**,
* **URL** kısmına ise **/iot** yazınız ve Done ile ayarları kaydedin.

![Nodered](/img/7.PNG)

Ekranda bulunan diğer **http response** düğümüne de çift tıklayarak;
*   **Status code** kısmına **200** yazın.
![Nodered](/img/8.PNG)

Son olarak yine arama ekranına **debug** yazarak çıkan düğümü de ekranınıza ekleyin. post komutu ile gelen istekleri nodered ekranına çıktı olarak atarımını sağlayacaktır. 

Düğümleri yapılandırdığımıza göre artık birleştirebiliriz. Bunun için düğümlerin sağında veya solunda bulunan gri kutuları fark etmişsinizdir. Birleştirmek için  **http in** düğümündeki gri kısma basılı tutarak **http response** çıkış düğümü üzerinde bulunan gri kutuya sürükleyin düğümlerin bağlandığını göreceksiniz. Ekstra olarak bir de sunucuya gelen post isteklerini de nodered üzerinen çıktı şeklinde görüntülenmesi için yine **http in** ile **debug** düğümlerini birleştirin.
Düğümleri bağladıktan sonra arayüzde bulunan sağ üst kısmındaki Deploy butonuna tıklayarak ayarları kaydedin.

![Nodered](/img/9.PNG)






