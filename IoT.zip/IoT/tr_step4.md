## Görsel Arayüz Tasarımı
NodeRed ekranın sağ üst kısmında bulunan debug simgesine tıklayarak cihazdan gelen verilen anlık olarak NodeRed üzerine aktarıldığını görebilirsiniz.

![Nodered](/img/10.PNG)

Son aşamada gelen bu verileri kullanarak NodeRed üzerinde bir görsel arayüz tasarımı yapacağız.

NodeRed ekranında bulunan sağ üst kısımdaki hamburger menüye tıklayın.

![Nodered](/img/11.PNG)

Açılan ekranda bulan **Manage Palette** kısmına gidin **Install** seçeneğine tıklayın arama yerine **node-red-dashboard** yazın ve çıkan kütüphaneyi kurun.

![Nodered](/img/12.PNG)

Çıkan uyarıya ekranında bulunan Install seçeneğine tıklayın ve artık NodeRed uygulamanız görsel bir arayüze (ui) sahip oldu.

![Nodered](/img/13.PNG)

NodeRed ekranına dönün ve sol taraftaki arama kısmına **function** yazarak 3 adet düğümü ekranına ekleyin ve **http in** düğümü ile bağlantısını gerçekleştirin.

![Nodered](/img/19.PNG)

Sırayla bu düğümlerden ilkine tıklayın.
* Name kısmına **sicaklik**
* **On Message** kısmına ise aşağıdaki ifadeyi yapıştırın. Bu kod post metodu ile aldığımız json dizisinden sadece sicaklik değerini çekecek ve ekranda güzel gözükmesi için virgülden sonra bir basamak alarak çıktı üretecektir.

```
msg.payload = Number(msg.payload['sicaklik'].toFixed(2))
return msg;
```
![Nodered](/img/15.PNG)

Aynı işlemleri hissedilen ve nem için de yapın.
* Name kısmına **hissedilen**
```
msg.payload = Number(msg.payload['hissedilen'].toFixed(2))
return msg;
```
![Nodered](/img/17.PNG)
* Name kısmına **nem**
```
msg.payload = Number(msg.payload['nem'].toFixed(2))
return msg;
```
![Nodered](/img/18.PNG)

Son olarak arayüz ekranına göstergeleri eklemek için arama yerine **gauge** yazın ve 3 adet düğüm ekleyerek her birini sicaklik, nem ve hissedilen düğümlerine tek tek bağlayın.

Eklediğiniz ilk **gauge** tıklayın. Açılan ekranda bulunan **Group** sekmesinin yanındaki edit kalemine tıklayın.

![Nodered](/img/21.PNG)

Açılan ekranda bulunan;

*   Name kısmına **Bulut Bilişimciler** yazın ve altta bulunan **Width** kısmını **15** yaptıktan sonra  **Tab** sekmesinin yanında bulunan kaleme tıklayın. 

![Nodered](/img/22.PNG)

Bu ekranda bulunan;
*   Name kısmına **Sıcaklık ve Nem Bilgileri** yazıp sağ üste bulunan Add tıklayın.

![Nodered](/img/23.PNG)

Tekrar Add tıklayın.

![Nodered](/img/24.PNG)

Bu ekranda bulunan;
* Size tıklayarak 5 x 5 boyut seçin,
* Type kısmından **Gauge** ile gösterimi seçin,
* Label kısmına **sicaklik**,
* Units kısmına sıcaklık birimi olan **°C** ,
* Range kısmındaki max ise 50 yapın ve Done ile kaydedin.

![Nodered](/img/25.PNG)

Diğer bir gauge tıklayın açılan sayfada bulunan **Group** kısmına tıkladığınızda daha önce oluşturduğumuz ayarları kullabilirsiniz. Bu ayarı seçin. Ardından Size tıklayarak 5 x 5 boyut seçin, Label kısmına **hissedilen** , Units kısma sıcaklık birimi olan **°C** ve **Range** kısmındaki max ise 50 yapın, Type gösterimini ise farklı gösterim olması amaçlı **Level** olarak değiştirin ve Done ile kaydedin.

![Nodered](/img/26.PNG)

Kalan son gauge tıklayın açılan sayfada bulunan **Group** kısmına tıkladığınızda daha önce oluşturduğumuz ayarları kullanın. Ardından Size tıklayarak 5 x 5 boyut seçin, Label kısmına **nem** , Units kısma nem birimi olan **g/m3** ve **Range** kısmındaki max ise 100 yapın, Type gösterimini ise farklı gösterim olması amaçlı **Donut** olarak değiştirin ve Done ile kaydedin.

![Nodered](/img/27.PNG)

Son durumde ekranınız aşadağı gibi gözükmesi gerekmektedir. 

![Nodered](/img/14.PNG)




