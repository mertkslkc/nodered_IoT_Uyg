## Görsel Arayüz 

Oluşturduğunuz adımlarda herhnagi bir hata almanız durumunda veyahut NodeRed ayarlarıyla uğraşmak istemeyenler için daha önceden oluşturulmuş NodeRed ayarlarını hızlı bir şekilde aktarmak içindir.

Node-Red arayüzünü açın. Menünün sağ üst kısmından Import sekmesine gidin.

![Nodered](https://miro.medium.com/v2/resize:fit:640/format:webp/1*61Hti0twWK5xzhxTGxbt_Q.png)

Açılan sayfa da select a file to import butonuna basın ve GitLab adresinden indirdiğiniz dosyanın içinde bulunan nodered.json belgesini yükleyin ve Import butonuna tıklayarak tüm ayarları aktarmış olacaksınız.

![Nodered](https://miro.medium.com/v2/resize:fit:1100/format:webp/1*YTOY9UeGeflPzABHt0oo5w.png)

Son durumde ekranınız aşadağı gibi gözükmesi gerekmektedir. 

![Nodered](/img/14.PNG)

Bulutbilişimciler platformu üzerinden ayağa kaldırdığımız NodeRed sunucunun adresinin sonuna /ui ifadesini ekleyerek başka bir sekmede açın.

Örnek Adres
```
https://ip10-3-104-4-ch6fb09od340kjsj0hlg-1880-nemrut00oap0.direct.bulutbilisimciler.com

Adresin sonuna /ui ifadesini ekleyin.

https://ip10-3-104-4-ch6fb09od340kjsj0hlg-1880-nemrut00oap0.direct.bulutbilisimciler.com/ui
```
NodeMCU kartına DHT11 sıcaklık sensörü ekleyerek HTTP protokolü üzerinden POST metodu ile BulutBilişimciler platformu üzerinden ayağa kaldırdığımız IoT sunucuna sensörden gelen anlık verileri NodeRed aracığıyla aktararak aynı zamanda da uygulamaya görsel bir arayayüz eklemiş olduk.

![Nodered](/img/28.PNG)

